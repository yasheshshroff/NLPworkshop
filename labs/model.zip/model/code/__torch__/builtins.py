class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  def forward(self: __torch__.builtins.Model,
    x: Tensor) -> Tensor:
    return torch.mul(x, CONSTANTS.c0)
